import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Activity {
    int start;
    int end;
    int value;

    public Activity(int start, int end, int value) {
        this.start = start;
        this.end = end;
        this.value = value;
    }
}

public class MaximizeActivityValue {
    public static int maximizeValue(List<Activity> activities) {
        // Сортируем заявки по времени начала
        Collections.sort(activities, Comparator.comparingInt(a -> a.start));

        int totalValue = 0;
        int currentTime = 9; // Начинаем с 9:00

        for (Activity activity : activities) {
            // Проверяем, не пересекается ли заявка с текущим временем
            if (activity.start >= currentTime) {
                // Добавляем заявку
                totalValue += activity.value;
                currentTime = activity.end; // Обновляем текущее время
            }
        }

        return totalValue;
    }

    public static void main(String[] args) {
        // Пример использования
        List<Activity> activities = new ArrayList<>();
        activities.add(new Activity(9, 13, 1));
        activities.add(new Activity(11, 14, 1));
        activities.add(new Activity(12, 16, 2));
        activities.add(new Activity(13, 17, 2));

        int result = maximizeValue(activities);
        System.out.println("Максимальная выгода: " + result);
    }
}